package com.socotra.deployment.customer.personalauto;

public class DocDataSnapshotPlugin {
  
}